import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

export const gamesService = {
  // Obter próximos jogos
  getUpcomingGames: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/games/upcoming`);
      return { success: true, data: response.data };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.error || 'Erro ao buscar próximos jogos' 
      };
    }
  },

  // Obter jogos ao vivo
  getLiveGames: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/games/live`);
      return { success: true, data: response.data };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.error || 'Erro ao buscar jogos ao vivo' 
      };
    }
  },

  // Popular jogos de exemplo (para desenvolvimento)
  populateSampleGames: async () => {
    try {
      const response = await axios.post(`${API_BASE_URL}/games/populate-sample`);
      return { success: true, data: response.data };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.error || 'Erro ao popular jogos de exemplo' 
      };
    }
  }
};

export const streamService = {
  // Obter URL de stream para um jogo
  getStreamUrl: async (gameId) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/stream/url/${gameId}`);
      return { success: true, data: response.data };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.error || 'Erro ao obter URL de stream' 
      };
    }
  },

  // Validar acesso ao stream
  validateStreamAccess: async () => {
    try {
      const response = await axios.post(`${API_BASE_URL}/stream/validate`);
      return { success: true, data: response.data };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.error || 'Erro ao validar acesso ao stream' 
      };
    }
  },

  // Obter URLs de teste para desenvolvimento
  getTestStreamUrls: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/stream/test-urls`);
      return { success: true, data: response.data };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.error || 'Erro ao obter URLs de teste' 
      };
    }
  }
};

