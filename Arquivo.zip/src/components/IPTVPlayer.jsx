import React, { useRef, useEffect, useState } from 'react';
import Hls from 'hls.js';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Play, Pause, Volume2, VolumeX, Maximize, Loader2, Tv } from 'lucide-react';

const IPTVPlayer = ({ streamUrl, gameInfo, onError }) => {
  const videoRef = useRef(null);
  const hlsRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    if (!streamUrl || !videoRef.current) return;

    const video = videoRef.current;
    setIsLoading(true);
    setError('');

    // Verificar se é um stream HLS
    if (streamUrl.includes('.m3u8')) {
      if (Hls.isSupported()) {
        const hls = new Hls({
          enableWorker: true,
          lowLatencyMode: true,
          backBufferLength: 90
        });

        hls.loadSource(streamUrl);
        hls.attachMedia(video);

        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          setIsLoading(false);
          console.log('Stream HLS carregado com sucesso');
        });

        hls.on(Hls.Events.ERROR, (event, data) => {
          console.error('Erro HLS:', data);
          setError('Erro ao carregar stream HLS');
          setIsLoading(false);
          if (onError) onError(data);
        });

        hlsRef.current = hls;
      } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
        // Safari nativo
        video.src = streamUrl;
        setIsLoading(false);
      } else {
        setError('Seu navegador não suporta streams HLS');
        setIsLoading(false);
      }
    } else {
      // Stream MP4 ou outros formatos
      video.src = streamUrl;
      setIsLoading(false);
    }

    // Event listeners do vídeo
    const handleLoadStart = () => setIsLoading(true);
    const handleCanPlay = () => setIsLoading(false);
    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleError = (e) => {
      setError('Erro ao reproduzir vídeo');
      setIsLoading(false);
      console.error('Erro de vídeo:', e);
    };

    video.addEventListener('loadstart', handleLoadStart);
    video.addEventListener('canplay', handleCanPlay);
    video.addEventListener('play', handlePlay);
    video.addEventListener('pause', handlePause);
    video.addEventListener('error', handleError);

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      video.removeEventListener('loadstart', handleLoadStart);
      video.removeEventListener('canplay', handleCanPlay);
      video.removeEventListener('play', handlePlay);
      video.removeEventListener('pause', handlePause);
      video.removeEventListener('error', handleError);
    };
  }, [streamUrl, onError]);

  const togglePlay = () => {
    if (!videoRef.current) return;

    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play().catch(err => {
        console.error('Erro ao reproduzir:', err);
        setError('Erro ao iniciar reprodução');
      });
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const toggleFullscreen = () => {
    if (!videoRef.current) return;

    if (!isFullscreen) {
      if (videoRef.current.requestFullscreen) {
        videoRef.current.requestFullscreen();
      } else if (videoRef.current.webkitRequestFullscreen) {
        videoRef.current.webkitRequestFullscreen();
      } else if (videoRef.current.mozRequestFullScreen) {
        videoRef.current.mozRequestFullScreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      }
    }
    setIsFullscreen(!isFullscreen);
  };

  if (!streamUrl) {
    return (
      <Card className="w-full bg-gray-900 border-gray-700">
        <CardContent className="p-8 text-center">
          <Tv className="w-16 h-16 mx-auto mb-4 text-gray-500" />
          <p className="text-gray-400">Nenhum stream disponível</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full">
      {/* Propaganda fixa no topo */}
      <Card className="w-full mb-4 bg-gradient-to-r from-yellow-600 to-yellow-500 border-yellow-400">
        <CardContent className="p-4 text-center">
          <p className="text-black font-bold text-lg">
            📺 Assine nossos canais IPTV! Filmes, séries e muito mais! 
            <span className="ml-2 underline cursor-pointer">Clique aqui</span>
          </p>
        </CardContent>
      </Card>

      {/* Player de vídeo */}
      <Card className="w-full bg-black border-gray-700">
        <CardHeader className="pb-2">
          <CardTitle className="text-white flex items-center gap-2">
            <Tv className="w-5 h-5" />
            {gameInfo ? `${gameInfo.home_team} vs ${gameInfo.away_team}` : 'Transmissão ao Vivo'}
          </CardTitle>
          {gameInfo && (
            <p className="text-gray-400 text-sm">{gameInfo.competition}</p>
          )}
        </CardHeader>
        <CardContent className="p-0">
          <div className="relative bg-black">
            <video
              ref={videoRef}
              className="w-full aspect-video"
              controls={false}
              playsInline
              muted={isMuted}
            />
            
            {/* Loading overlay */}
            {isLoading && (
              <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                <div className="text-center text-white">
                  <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2" />
                  <p>Carregando stream...</p>
                </div>
              </div>
            )}

            {/* Controles customizados */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={togglePlay}
                    className="text-white hover:bg-white/20"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                  
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={toggleMute}
                    className="text-white hover:bg-white/20"
                  >
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </Button>
                </div>

                <Button
                  size="sm"
                  variant="ghost"
                  onClick={toggleFullscreen}
                  className="text-white hover:bg-white/20"
                >
                  <Maximize className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {error && (
            <div className="p-4">
              <Alert className="bg-red-500/20 border-red-500/50">
                <AlertDescription className="text-red-200">{error}</AlertDescription>
              </Alert>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default IPTVPlayer;

