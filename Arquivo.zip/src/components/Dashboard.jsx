import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LogOut, User, Tv, Calendar } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import IPTVPlayer from './IPTVPlayer';
import GamesSchedule from './GamesSchedule';
import botafogoLogo from '@/assets/botafogo-logo.png';

const Dashboard = () => {
  const { user, logout } = useAuth();
  const [currentStream, setCurrentStream] = useState(null);
  const [currentGame, setCurrentGame] = useState(null);
  const [activeTab, setActiveTab] = useState('live');

  const handleWatchLive = (streamUrl, gameInfo) => {
    setCurrentStream(streamUrl);
    setCurrentGame(gameInfo);
    setActiveTab('live');
  };

  const handleStreamError = (error) => {
    console.error('Erro no stream:', error);
    // Aqui você pode implementar lógica adicional para lidar com erros
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      {/* Header */}
      <header className="bg-black/50 backdrop-blur-md border-b border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img src={botafogoLogo} alt="Botafogo" className="w-10 h-10" />
              <div>
                <h1 className="text-white text-2xl font-bold">ClubeFogo</h1>
                <p className="text-gray-400 text-sm">Portal do Torcedor</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-white font-medium">{user?.name}</p>
                <p className="text-gray-400 text-sm">{user?.email}</p>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={logout}
                className="border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex gap-2 mb-6">
          <Button
            variant={activeTab === 'live' ? 'default' : 'outline'}
            onClick={() => setActiveTab('live')}
            className={activeTab === 'live' 
              ? 'bg-white text-black' 
              : 'border-gray-600 text-gray-300 hover:bg-gray-800'
            }
          >
            <Tv className="w-4 h-4 mr-2" />
            Transmissão
          </Button>
          <Button
            variant={activeTab === 'schedule' ? 'default' : 'outline'}
            onClick={() => setActiveTab('schedule')}
            className={activeTab === 'schedule' 
              ? 'bg-white text-black' 
              : 'border-gray-600 text-gray-300 hover:bg-gray-800'
            }
          >
            <Calendar className="w-4 h-4 mr-2" />
            Agenda
          </Button>
        </div>

        {/* Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {activeTab === 'live' && (
              <div className="space-y-6">
                <IPTVPlayer 
                  streamUrl={currentStream}
                  gameInfo={currentGame}
                  onError={handleStreamError}
                />
                
                {!currentStream && (
                  <Card className="bg-gray-900 border-gray-700">
                    <CardContent className="p-8 text-center">
                      <Tv className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                      <h3 className="text-white text-xl font-semibold mb-2">
                        Nenhuma transmissão ativa
                      </h3>
                      <p className="text-gray-400 mb-4">
                        Selecione um jogo ao vivo na agenda para assistir
                      </p>
                      <Button 
                        onClick={() => setActiveTab('schedule')}
                        className="bg-white text-black hover:bg-gray-200"
                      >
                        Ver Agenda
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}

            {activeTab === 'schedule' && (
              <GamesSchedule onWatchLive={handleWatchLive} />
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* User Info */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Perfil
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div>
                    <p className="text-gray-400 text-sm">Nome</p>
                    <p className="text-white">{user?.name}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">E-mail</p>
                    <p className="text-white">{user?.email}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">WhatsApp</p>
                    <p className="text-white">{user?.whatsapp}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Status</p>
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-500/20 text-green-400">
                      Verificado
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Ações Rápidas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full border-gray-600 text-gray-300 hover:bg-gray-800"
                  onClick={() => setActiveTab('live')}
                >
                  <Tv className="w-4 h-4 mr-2" />
                  Ver Transmissões
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full border-gray-600 text-gray-300 hover:bg-gray-800"
                  onClick={() => setActiveTab('schedule')}
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Próximos Jogos
                </Button>
              </CardContent>
            </Card>

            {/* Botafogo Info */}
            <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <img src={botafogoLogo} alt="Botafogo" className="w-16 h-16 mx-auto mb-4" />
                <h3 className="text-white font-bold text-lg mb-2">
                  Botafogo de Futebol e Regatas
                </h3>
                <p className="text-gray-400 text-sm">
                  Fundado em 1904 • Rio de Janeiro
                </p>
                <p className="text-gray-400 text-sm mt-2">
                  "De tradições e glórias, de lutas e vitórias"
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

