import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Calendar, Clock, Trophy, Play, Loader2, RefreshCw } from 'lucide-react';
import { gamesService, streamService } from '@/services/api';

const GamesSchedule = ({ onWatchLive }) => {
  const [upcomingGames, setUpcomingGames] = useState([]);
  const [liveGames, setLiveGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const loadGames = async () => {
    setLoading(true);
    setError('');

    try {
      // Carregar jogos ao vivo
      const liveResult = await gamesService.getLiveGames();
      if (liveResult.success) {
        setLiveGames(liveResult.data.games);
      }

      // Carregar próximos jogos
      const upcomingResult = await gamesService.getUpcomingGames();
      if (upcomingResult.success) {
        setUpcomingGames(upcomingResult.data.games);
      } else {
        setError(upcomingResult.error);
      }
    } catch (err) {
      setError('Erro ao carregar jogos');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadGames();
    
    // Atualizar jogos a cada 30 segundos
    const interval = setInterval(loadGames, 30000);
    return () => clearInterval(interval);
  }, []);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const formatTime = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleWatchLive = async (game) => {
    try {
      const result = await streamService.getStreamUrl(game.id);
      if (result.success) {
        onWatchLive(result.data.stream_url, game);
      } else {
        setError(result.error);
      }
    } catch (err) {
      setError('Erro ao obter stream');
    }
  };

  const populateSampleGames = async () => {
    setLoading(true);
    try {
      await gamesService.populateSampleGames();
      await loadGames();
    } catch (err) {
      setError('Erro ao popular jogos de exemplo');
    }
    setLoading(false);
  };

  if (loading && upcomingGames.length === 0 && liveGames.length === 0) {
    return (
      <div className="space-y-6">
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-8 text-center">
            <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-white" />
            <p className="text-gray-400">Carregando jogos...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Jogos ao Vivo */}
      {liveGames.length > 0 && (
        <Card className="bg-gradient-to-r from-red-900 to-red-800 border-red-600">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Play className="w-5 h-5 text-red-400" />
              Ao Vivo Agora
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {liveGames.map((game) => (
              <div key={game.id} className="bg-black/30 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-bold text-lg">
                      {game.home_team} vs {game.away_team}
                    </h3>
                    <div className="flex items-center gap-4 mt-2">
                      <Badge variant="destructive" className="bg-red-600">
                        AO VIVO
                      </Badge>
                      <span className="text-gray-300 flex items-center gap-1">
                        <Trophy className="w-4 h-4" />
                        {game.competition}
                      </span>
                    </div>
                  </div>
                  <Button 
                    onClick={() => handleWatchLive(game)}
                    className="bg-white text-black hover:bg-gray-200"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Assistir
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Próximos Jogos */}
      <Card className="bg-gray-900 border-gray-700">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Próximos Jogos
          </CardTitle>
          <Button 
            variant="outline" 
            size="sm"
            onClick={loadGames}
            disabled={loading}
            className="border-gray-600 text-gray-300 hover:bg-gray-800"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </CardHeader>
        <CardContent>
          {upcomingGames.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12 mx-auto mb-4 text-gray-500" />
              <p className="text-gray-400 mb-4">Nenhum jogo agendado encontrado</p>
              <Button 
                onClick={populateSampleGames}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                Carregar Jogos de Exemplo
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {upcomingGames.map((game) => (
                <div key={game.id} className="bg-gray-800 rounded-lg p-4 hover:bg-gray-750 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="text-white font-semibold text-lg">
                        {game.home_team} vs {game.away_team}
                      </h3>
                      <div className="flex items-center gap-4 mt-2 text-sm">
                        <span className="text-gray-300 flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {formatDate(game.date)}
                        </span>
                        <span className="text-gray-300 flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {formatTime(game.date)}
                        </span>
                        <span className="text-gray-300 flex items-center gap-1">
                          <Trophy className="w-4 h-4" />
                          {game.competition}
                        </span>
                      </div>
                    </div>
                    <Badge variant="outline" className="border-gray-600 text-gray-300">
                      Agendado
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {error && (
        <Alert className="bg-red-500/20 border-red-500/50">
          <AlertDescription className="text-red-200">{error}</AlertDescription>
        </Alert>
      )}
    </div>
  );
};

export default GamesSchedule;

